console.log("Question3\n A)--> Creation of a array of object\n B)-->function to print all the objects on console")

let data = [
        {
        name : "Sachin",
        age  :  21,
    country  : "India",
    hobbies  : ["Games","Movies","Bike riding"],
        },

        {
            name : "Nishant",
            age  :  20,
        country  : "India",
        hobbies  : ["singing","Dancing"],
        },

        {
            name : "ALex",
            age  :  30,
        country  : "USA",
        hobbies  : ["singing","Dancing","Skating"],
        },

    
        {
            name : "Mukul",
            age  :  31,
        country  : "India",
        hobbies  : ["singing","Dancing","Cricket"],
        }
]
// Function to print all Objects

function printData(){
    data.forEach(function(person){
        console.log(person);
    })
}

printData();
