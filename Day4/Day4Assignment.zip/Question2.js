function copy(){
    const inp1 = document.getElementById("input1");
    const inp2 = document.getElementById("input2")
    inp2.value = inp1.value
}