function originalImage()
{
 const ele = document.getElementById("image")
 const oimage = "https://footwearnews.com/wp-content/uploads/2019/12/tom-jerry-cartoon.jpg?w=1024";
 ele.src = oimage;
}
function changeImage()
{
    const ele =document.getElementById("image");
    const newimg = "https://i.pinimg.com/originals/a7/67/bc/a767bc552035a0ee7fa1388896d7a52b.jpg";
    ele.src = newimg;
}

function thirdImage(){
    const ele = document.getElementById("image");
    const image_3 ="https://i.guim.co.uk/img/static/sys-images/Guardian/Pix/pictures/2014/10/2/1412247581515/Tom-and-Jerry-014.jpg?width=700&quality=85&auto=format&fit=max&s=6385bc7016cee682b8c642103f17650a";
    ele.src = image_3;  
}