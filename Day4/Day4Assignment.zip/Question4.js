let data = [
    {
    name : "Sachin",
    age  :  21,
country  : "India",
hobbies  : ["Games","Movies","Bike riding"],
    },

    {
        name : "Nishant",
        age  :  20,
    country  : "India",
    hobbies  : ["singing","Dancing"],
    },

    {
        name : "ALex",
        age  :  30,
    country  : "USA",
    hobbies  : ["singing","Dancing","Skating"],
    },


    {
        name : "Mukul",
        age  :  31,
    country  : "India",
    hobbies  : ["singing","Dancing","Cricket"],
    }
]


console.log("Question 4\n A)--> Function to print all objects having age les than 30\n B)-->Function to print all objects having Country India ")

console.log("age les than 30");
function getAge(){
    for(let i=0;i<data.length;i++)
    {
        if(data[i].age<30)
        {
            let element1 = data[i];
            console.log(`Name: ${element1.name}\n Age: ${element1.age}\n Country: ${element1.country}\n Hobbies: ${element1.hobbies}`);
        }
    }
}
getAge();


console.log("Country is india")
function getCountry(){
    for(let i=0;i<data.length;i++)
    {
        if(data[i].country == "India")
        {
            let element2 = data[i];
            console.log(`Name: ${element2.name}\n Age: ${element2.age}\n Country: ${element2.country}\n Hobbies: ${element2.hobbies}`);
        }
    }
}
getCountry();